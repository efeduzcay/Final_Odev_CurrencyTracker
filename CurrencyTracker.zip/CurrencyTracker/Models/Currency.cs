namespace CurrencyTracker.Models;

public class Currency
{
    public string Code { get; set; } = string.Empty;
    public decimal Rate { get; set; }
}
