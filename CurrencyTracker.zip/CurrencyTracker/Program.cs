using CurrencyTracker.Models;
using CurrencyTracker.Services;

class Program
{
    static async Task Main(string[] args)
    {
        CurrencyService service = new CurrencyService();
        var currencies = await service.GetCurrenciesAsync();

        if (currencies.Count == 0)
        {
            Console.WriteLine("Döviz verisi alınamadı.");
            return;
        }

        while (true)
        {
            Console.WriteLine("\n===== CurrencyTracker =====");
            Console.WriteLine("1. Tüm dövizleri listele");
            Console.WriteLine("2. Koda göre döviz ara");
            Console.WriteLine("3. Belirli bir değerden büyük dövizleri listele");
            Console.WriteLine("4. Dövizleri değere göre sırala");
            Console.WriteLine("5. İstatistiksel özet göster");
            Console.WriteLine("0. Çıkış");
            Console.Write("Seçiminiz: ");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    currencies.Select(c => $"{c.Code} - {c.Rate}")
                        .ToList()
                        .ForEach(Console.WriteLine);
                    break;

                case "2":
                    Console.Write("Döviz kodu girin: ");
                    string code = Console.ReadLine() ?? string.Empty;

                    currencies.Where(c =>
                        c.Code.Equals(code, StringComparison.OrdinalIgnoreCase))
                        .ToList()
                        .ForEach(c => Console.WriteLine($"{c.Code} - {c.Rate}"));
                    break;

                case "3":
                    Console.Write("Minimum değer girin: ");
                    decimal minValue = decimal.Parse(Console.ReadLine());

                    currencies.Where(c => c.Rate > minValue)
                        .ToList()
                        .ForEach(c => Console.WriteLine($"{c.Code} - {c.Rate}"));
                    break;

                case "4":
                    Console.WriteLine("1- Artan | 2- Azalan");
                    string order = Console.ReadLine();

                    var sorted = order == "1"
                        ? currencies.OrderBy(c => c.Rate)
                        : currencies.OrderByDescending(c => c.Rate);

                    foreach (var c in sorted)
                        Console.WriteLine($"{c.Code} - {c.Rate}");
                    break;

                case "5":
                    Console.WriteLine($"Toplam Döviz Sayısı: {currencies.Count()}");
                    Console.WriteLine($"En Yüksek Kur: {currencies.Max(c => c.Rate)}");
                    Console.WriteLine($"En Düşük Kur: {currencies.Min(c => c.Rate)}");
                    Console.WriteLine($"Ortalama Kur: {currencies.Average(c => c.Rate)}");
                    break;

                case "0":
                    return;
            }
        }
    }
}
