# CurrencyTracker – Döviz Takip Konsol Uygulaması

## Öğrenci Bilgileri
Ad Soyad: Efe Düzçay  
Öğrenci No: 20230108057  

## Açıklama
Frankfurter API kullanılarak geliştirilen, LINQ tabanlı C# Console döviz takip uygulaması.
