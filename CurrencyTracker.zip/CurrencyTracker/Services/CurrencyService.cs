using System.Text.Json;
using CurrencyTracker.Models;

namespace CurrencyTracker.Services
{
    public class CurrencyService
    {
        private readonly HttpClient _httpClient = new HttpClient();

        public async Task<List<Currency>> GetCurrenciesAsync()
        {
            var json = await _httpClient.GetStringAsync(
                "https://api.frankfurter.app/latest?from=TRY");

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var response = JsonSerializer.Deserialize<CurrencyResponse>(json, options);

            if (response?.Rates == null)
                return new List<Currency>();

            return response.Rates
                .Select(r => new Currency
                {
                    Code = r.Key,
                    Rate = r.Value
                })
                .ToList();
        }
    }
}
